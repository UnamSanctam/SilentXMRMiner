#pragma once

#include <windows.h>

#define SW2_SEED 0xD661962C
#define SW2_ROL8(v) (v << 8 | v >> 24)
#define SW2_ROR8(v) (v >> 8 | v << 24)
#define SW2_ROX8(v) ((SW2_SEED % 2) ? SW2_ROL8(v) : SW2_ROR8(v))
#define SW2_MAX_ENTRIES 500
#define SW2_RVA2VA(Type, DllBase, Rva) (Type)((ULONG_PTR) DllBase + Rva)

typedef struct _SW2_SYSCALL_ENTRY
{
    DWORD Hash;
    DWORD Address;
} SW2_SYSCALL_ENTRY, *PSW2_SYSCALL_ENTRY;

typedef struct _SW2_SYSCALL_LIST
{
    DWORD Count;
    SW2_SYSCALL_ENTRY Entries[SW2_MAX_ENTRIES];
} SW2_SYSCALL_LIST, *PSW2_SYSCALL_LIST;

typedef struct _SW2_PEB_LDR_DATA {
	BYTE Reserved1[8];
	PVOID Reserved2[3];
	LIST_ENTRY InMemoryOrderModuleList;
} SW2_PEB_LDR_DATA, *PSW2_PEB_LDR_DATA;

typedef struct _SW2_LDR_DATA_TABLE_ENTRY {
	PVOID Reserved1[2];
	LIST_ENTRY InMemoryOrderLinks;
	PVOID Reserved2[2];
	PVOID DllBase;
} SW2_LDR_DATA_TABLE_ENTRY, *PSW2_LDR_DATA_TABLE_ENTRY;

typedef struct _SW2_PEB {
	BYTE Reserved1[2];
	BYTE BeingDebugged;
	BYTE Reserved2[1];
	PVOID Reserved3[2];
	PSW2_PEB_LDR_DATA Ldr;
} SW2_PEB, *PSW2_PEB;

DWORD SW2_HashSyscall(PCSTR FunctionName);
BOOL SW2_PopulateSyscallList();
EXTERN_C DWORD SW2_GetSyscallNumber(DWORD FunctionHash);

typedef struct _SYSTEM_HANDLE
{
	ULONG ProcessId;
	BYTE ObjectTypeNumber;
	BYTE Flags;
	USHORT Handle;
	PVOID Object;
	ACCESS_MASK GrantedAccess;
} SYSTEM_HANDLE, *PSYSTEM_HANDLE;

typedef struct _IO_STATUS_BLOCK
{
	union
	{
		LONG Status;
		VOID*    Pointer;
	};
	ULONG_PTR Information;
} IO_STATUS_BLOCK, *PIO_STATUS_BLOCK;


typedef VOID(KNORMAL_ROUTINE) (
	IN PVOID NormalContext,
	IN PVOID SystemArgument1,
	IN PVOID SystemArgument2);

typedef struct _PS_ATTRIBUTE
{
	ULONG  Attribute;
	SIZE_T Size;
	union
	{
		ULONG Value;
		PVOID ValuePtr;
	} u1;
	PSIZE_T ReturnLength;
} PS_ATTRIBUTE, *PPS_ATTRIBUTE;


#ifndef InitializeObjectAttributes
#define InitializeObjectAttributes( p, n, a, r, s ) { \
	(p)->Length = sizeof( OBJECT_ATTRIBUTES );        \
	(p)->RootDirectory = r;                           \
	(p)->Attributes = a;                              \
	(p)->ObjectName = n;                              \
	(p)->SecurityDescriptor = s;                      \
	(p)->SecurityQualityOfService = NULL;             \
}
#endif




typedef enum _PROCESSINFOCLASS
{
	ProcessBasicInformation = 0,
	ProcessDebugPort = 7,
	ProcessWow64Information = 26,
	ProcessImageFileName = 27,
	ProcessBreakOnTermination = 29
} PROCESSINFOCLASS, *PPROCESSINFOCLASS;

typedef enum _WAIT_TYPE
{
	WaitAll = 0,
	WaitAny = 1
} WAIT_TYPE, *PWAIT_TYPE;

typedef VOID(NTAPI* PIO_APC_ROUTINE) (
	IN PVOID            ApcContext,
	IN PIO_STATUS_BLOCK IoStatusBlock,
	IN ULONG            Reserved);

typedef KNORMAL_ROUTINE* PKNORMAL_ROUTINE;

typedef enum _THREADINFOCLASS
{
	ThreadBasicInformation,
	ThreadTimes,
	ThreadPriority,
	ThreadBasePriority,
	ThreadAffinityMask,
	ThreadImpersonationToken,
	ThreadDescriptorTableEntry,
	ThreadEnableAlignmentFaultFixup,
	ThreadEventPair_Reusable,
	ThreadQuerySetWin32StartAddress,
	ThreadZeroTlsCell,
	ThreadPerformanceCount,
	ThreadAmILastThread,
	ThreadIdealProcessor,
	ThreadPriorityBoost,
	ThreadSetTlsArrayAddress,
	ThreadIsIoPending,
	ThreadHideFromDebugger,
	ThreadBreakOnTermination,
	MaxThreadInfoClass
} THREADINFOCLASS, *PTHREADINFOCLASS;

typedef enum _SECTION_INHERIT
{
	ViewShare = 1,
	ViewUnmap = 2
} SECTION_INHERIT, *PSECTION_INHERIT;

typedef enum _FILE_INFORMATION_CLASS
{
	FileDirectoryInformation = 1,
	FileFullDirectoryInformation = 2,
	FileBothDirectoryInformation = 3,
	FileBasicInformation = 4,
	FileStandardInformation = 5,
	FileInternalInformation = 6,
	FileEaInformation = 7,
	FileAccessInformation = 8,
	FileNameInformation = 9,
	FileRenameInformation = 10,
	FileLinkInformation = 11,
	FileNamesInformation = 12,
	FileDispositionInformation = 13,
	FilePositionInformation = 14,
	FileFullEaInformation = 15,
	FileModeInformation = 16,
	FileAlignmentInformation = 17,
	FileAllInformation = 18,
	FileAllocationInformation = 19,
	FileEndOfFileInformation = 20,
	FileAlternateNameInformation = 21,
	FileStreamInformation = 22,
	FilePipeInformation = 23,
	FilePipeLocalInformation = 24,
	FilePipeRemoteInformation = 25,
	FileMailslotQueryInformation = 26,
	FileMailslotSetInformation = 27,
	FileCompressionInformation = 28,
	FileObjectIdInformation = 29,
	FileCompletionInformation = 30,
	FileMoveClusterInformation = 31,
	FileQuotaInformation = 32,
	FileReparsePointInformation = 33,
	FileNetworkOpenInformation = 34,
	FileAttributeTagInformation = 35,
	FileTrackingInformation = 36,
	FileIdBothDirectoryInformation = 37,
	FileIdFullDirectoryInformation = 38,
	FileValidDataLengthInformation = 39,
	FileShortNameInformation = 40,
	FileIoCompletionNotificationInformation = 41,
	FileIoStatusBlockRangeInformation = 42,
	FileIoPriorityHintInformation = 43,
	FileSfioReserveInformation = 44,
	FileSfioVolumeInformation = 45,
	FileHardLinkInformation = 46,
	FileProcessIdsUsingFileInformation = 47,
	FileNormalizedNameInformation = 48,
	FileNetworkPhysicalNameInformation = 49,
	FileIdGlobalTxDirectoryInformation = 50,
	FileIsRemoteDeviceInformation = 51,
	FileUnusedInformation = 52,
	FileNumaNodeInformation = 53,
	FileStandardLinkInformation = 54,
	FileRemoteProtocolInformation = 55,
	FileRenameInformationBypassAccessCheck = 56,
	FileLinkInformationBypassAccessCheck = 57,
	FileVolumeNameInformation = 58,
	FileIdInformation = 59,
	FileIdExtdDirectoryInformation = 60,
	FileReplaceCompletionInformation = 61,
	FileHardLinkFullIdInformation = 62,
	FileIdExtdBothDirectoryInformation = 63,
	FileDispositionInformationEx = 64,
	FileRenameInformationEx = 65,
	FileRenameInformationExBypassAccessCheck = 66,
	FileMaximumInformation = 67,
} FILE_INFORMATION_CLASS, *PFILE_INFORMATION_CLASS;

typedef struct _PS_ATTRIBUTE_LIST
{
	SIZE_T       TotalLength;
	PS_ATTRIBUTE Attributes[1];
} PS_ATTRIBUTE_LIST, *PPS_ATTRIBUTE_LIST;

typedef struct _UNICODE_STRING
{
	USHORT Length;
	USHORT MaximumLength;
	PWSTR  Buffer;
} UNICODE_STRING, *PUNICODE_STRING;

typedef struct _OBJECT_ATTRIBUTES
{
	ULONG           Length;
	HANDLE          RootDirectory;
	PUNICODE_STRING ObjectName;
	ULONG           Attributes;
	PVOID           SecurityDescriptor;
	PVOID           SecurityQualityOfService;
} OBJECT_ATTRIBUTES, *POBJECT_ATTRIBUTES;

typedef struct _CLIENT_ID
{
	HANDLE UniqueProcess;
	HANDLE UniqueThread;
} CLIENT_ID, *PCLIENT_ID;

typedef enum _SYSTEM_INFORMATION_CLASS
{
	SystemBasicInformation = 0,
	SystemPerformanceInformation = 2,
	SystemTimeOfDayInformation = 3,
	SystemProcessInformation = 5,
	SystemProcessorPerformanceInformation = 8,
	SystemHandleInformation = 16,
	SystemInterruptInformation = 23,
	SystemExceptionInformation = 33,
	SystemRegistryQuotaInformation = 37,
	SystemLookasideInformation = 45,
	SystemCodeIntegrityInformation = 103,
	SystemPolicyInformation = 134,
} SYSTEM_INFORMATION_CLASS, *PSYSTEM_INFORMATION_CLASS;

typedef enum _PS_CREATE_STATE
{
	PsCreateInitialState,
	PsCreateFailOnFileOpen,
	PsCreateFailOnSectionCreate,
	PsCreateFailExeFormat,
	PsCreateFailMachineMismatch,
	PsCreateFailExeName,
	PsCreateSuccess,
	PsCreateMaximumStates
} PS_CREATE_STATE, *PPS_CREATE_STATE;


typedef struct _PS_CREATE_INFO
{
	SIZE_T Size;
	PS_CREATE_STATE State;
	union
	{
		struct {
			union {
				ULONG InitFlags;
				struct {
					UCHAR  WriteOutputOnExit : 1;
					UCHAR  DetectManifest : 1;
					UCHAR  IFEOSkipDebugger : 1;
					UCHAR  IFEODoNotPropagateKeyState : 1;
					UCHAR  SpareBits1 : 4;
					UCHAR  SpareBits2 : 8;
					USHORT ProhibitedImageCharacteristics : 16;
				};
			};
			ACCESS_MASK AdditionalFileAccess;
		} InitState;
		struct {
			HANDLE FileHandle;
		} FailSection;
		struct {
			USHORT DllCharacteristics;
		} ExeFormat;
		struct {
			HANDLE IFEOKey;
		} ExeName;
		struct {
			union {
				ULONG OutputFlags;
				struct {
					UCHAR  ProtectedProcess : 1;
					UCHAR  AddressSpaceOverride : 1;
					UCHAR  DevOverrideEnabled : 1;
					UCHAR  ManifestDetected : 1;
					UCHAR  ProtectedProcessLight : 1;
					UCHAR  SpareBits1 : 3;
					UCHAR  SpareBits2 : 8;
					USHORT SpareBits3 : 16;
				};
			};
			HANDLE    FileHandle;
			HANDLE    SectionHandle;
			ULONGLONG UserProcessParametersNative;
			ULONG     UserProcessParametersWow64;
			ULONG     CurrentParameterFlags;
			ULONGLONG PebAddressNative;
			ULONG     PebAddressWow64;
			ULONGLONG ManifestAddress;
			ULONG     ManifestSize;
		} SuccessState;
	};
} PS_CREATE_INFO, *PPS_CREATE_INFO;

EXTERN_C LONG NtCreateProcess(
	OUT PHANDLE ProcessHandle,
	IN ACCESS_MASK DesiredAccess,
	IN POBJECT_ATTRIBUTES ObjectAttributes OPTIONAL,
	IN HANDLE ParentProcess,
	IN BOOLEAN InheritObjectTable,
	IN HANDLE SectionHandle OPTIONAL,
	IN HANDLE DebugPort OPTIONAL,
	IN HANDLE ExceptionPort OPTIONAL);

EXTERN_C LONG NtCreateThreadEx(
	OUT PHANDLE ThreadHandle,
	IN ACCESS_MASK DesiredAccess,
	IN POBJECT_ATTRIBUTES ObjectAttributes OPTIONAL,
	IN HANDLE ProcessHandle,
	IN PVOID StartRoutine,
	IN PVOID Argument OPTIONAL,
	IN ULONG CreateFlags,
	IN SIZE_T ZeroBits,
	IN SIZE_T StackSize,
	IN SIZE_T MaximumStackSize,
	IN PPS_ATTRIBUTE_LIST AttributeList OPTIONAL);

EXTERN_C LONG NtOpenProcess(
	OUT PHANDLE ProcessHandle,
	IN ACCESS_MASK DesiredAccess,
	IN POBJECT_ATTRIBUTES ObjectAttributes,
	IN PCLIENT_ID ClientId OPTIONAL);

EXTERN_C LONG NtOpenProcessToken(
	IN HANDLE ProcessHandle,
	IN ACCESS_MASK DesiredAccess,
	OUT PHANDLE TokenHandle);

EXTERN_C LONG NtTestAlert();

EXTERN_C LONG NtOpenThread(
	OUT PHANDLE ThreadHandle,
	IN ACCESS_MASK DesiredAccess,
	IN POBJECT_ATTRIBUTES ObjectAttributes,
	IN PCLIENT_ID ClientId OPTIONAL);

EXTERN_C LONG NtSuspendProcess(
	IN HANDLE ProcessHandle);

EXTERN_C LONG NtSuspendThread(
	IN HANDLE ThreadHandle,
	OUT PULONG PreviousSuspendCount);

EXTERN_C LONG NtResumeProcess(
	IN HANDLE ProcessHandle);

EXTERN_C LONG NtResumeThread(
	IN HANDLE ThreadHandle,
	IN OUT PULONG PreviousSuspendCount OPTIONAL);

EXTERN_C LONG NtGetContextThread(
	IN HANDLE ThreadHandle,
	IN OUT PCONTEXT ThreadContext);

EXTERN_C LONG NtSetContextThread(
	IN HANDLE ThreadHandle,
	IN PCONTEXT Context);

EXTERN_C LONG NtClose(
	IN HANDLE Handle);

EXTERN_C LONG NtReadVirtualMemory(
	IN HANDLE ProcessHandle,
	IN PVOID BaseAddress OPTIONAL,
	OUT PVOID Buffer,
	IN SIZE_T BufferSize,
	OUT PSIZE_T NumberOfBytesRead OPTIONAL);

EXTERN_C LONG NtWriteVirtualMemory(
	IN HANDLE ProcessHandle,
	IN PVOID BaseAddress,
	IN PVOID Buffer,
	IN SIZE_T NumberOfBytesToWrite,
	OUT PSIZE_T NumberOfBytesWritten OPTIONAL);

EXTERN_C LONG NtAllocateVirtualMemory(
	IN HANDLE ProcessHandle,
	IN OUT PVOID * BaseAddress,
	IN ULONG ZeroBits,
	IN OUT PSIZE_T RegionSize,
	IN ULONG AllocationType,
	IN ULONG Protect);

EXTERN_C LONG NtProtectVirtualMemory(
	IN HANDLE ProcessHandle,
	IN OUT PVOID * BaseAddress,
	IN OUT PSIZE_T RegionSize,
	IN ULONG NewProtect,
	OUT PULONG OldProtect);

EXTERN_C LONG NtFreeVirtualMemory(
	IN HANDLE ProcessHandle,
	IN OUT PVOID * BaseAddress,
	IN OUT PSIZE_T RegionSize,
	IN ULONG FreeType);

EXTERN_C LONG NtQuerySystemInformation(
	IN SYSTEM_INFORMATION_CLASS SystemInformationClass,
	IN OUT PVOID SystemInformation,
	IN ULONG SystemInformationLength,
	OUT PULONG ReturnLength OPTIONAL);

EXTERN_C LONG NtQueryDirectoryFile(
	IN HANDLE FileHandle,
	IN HANDLE Event OPTIONAL,
	IN PIO_APC_ROUTINE ApcRoutine OPTIONAL,
	IN PVOID ApcContext OPTIONAL,
	OUT PIO_STATUS_BLOCK IoStatusBlock,
	OUT PVOID FileInformation,
	IN ULONG Length,
	IN FILE_INFORMATION_CLASS FileInformationClass,
	IN BOOLEAN ReturnSingleEntry,
	IN PUNICODE_STRING FileName OPTIONAL,
	IN BOOLEAN RestartScan);

EXTERN_C LONG NtQueryInformationFile(
	IN HANDLE FileHandle,
	OUT PIO_STATUS_BLOCK IoStatusBlock,
	OUT PVOID FileInformation,
	IN ULONG Length,
	IN FILE_INFORMATION_CLASS FileInformationClass);

EXTERN_C LONG NtQueryInformationProcess(
	IN HANDLE ProcessHandle,
	IN PROCESSINFOCLASS ProcessInformationClass,
	OUT PVOID ProcessInformation,
	IN ULONG ProcessInformationLength,
	OUT PULONG ReturnLength OPTIONAL);

EXTERN_C LONG NtQueryInformationThread(
	IN HANDLE ThreadHandle,
	IN THREADINFOCLASS ThreadInformationClass,
	OUT PVOID ThreadInformation,
	IN ULONG ThreadInformationLength,
	OUT PULONG ReturnLength OPTIONAL);

EXTERN_C LONG NtCreateSection(
	OUT PHANDLE SectionHandle,
	IN ACCESS_MASK DesiredAccess,
	IN POBJECT_ATTRIBUTES ObjectAttributes OPTIONAL,
	IN PLARGE_INTEGER MaximumSize OPTIONAL,
	IN ULONG SectionPageProtection,
	IN ULONG AllocationAttributes,
	IN HANDLE FileHandle OPTIONAL);

EXTERN_C LONG NtOpenSection(
	OUT PHANDLE SectionHandle,
	IN ACCESS_MASK DesiredAccess,
	IN POBJECT_ATTRIBUTES ObjectAttributes);

EXTERN_C LONG NtMapViewOfSection(
	IN HANDLE SectionHandle,
	IN HANDLE ProcessHandle,
	IN OUT PVOID BaseAddress,
	IN ULONG ZeroBits,
	IN SIZE_T CommitSize,
	IN OUT PLARGE_INTEGER SectionOffset OPTIONAL,
	IN OUT PSIZE_T ViewSize,
	IN SECTION_INHERIT InheritDisposition,
	IN ULONG AllocationType,
	IN ULONG Win32Protect);

EXTERN_C LONG NtUnmapViewOfSection(
	IN HANDLE ProcessHandle,
	IN PVOID BaseAddress);

EXTERN_C LONG NtAdjustPrivilegesToken(
	IN HANDLE TokenHandle,
	IN BOOLEAN DisableAllPrivileges,
	IN PTOKEN_PRIVILEGES NewState OPTIONAL,
	IN ULONG BufferLength,
	OUT PTOKEN_PRIVILEGES PreviousState OPTIONAL,
	OUT PULONG ReturnLength OPTIONAL);

EXTERN_C LONG NtDeviceIoControlFile(
	IN HANDLE FileHandle,
	IN HANDLE Event OPTIONAL,
	IN PIO_APC_ROUTINE ApcRoutine OPTIONAL,
	IN PVOID ApcContext OPTIONAL,
	OUT PIO_STATUS_BLOCK IoStatusBlock,
	IN ULONG IoControlCode,
	IN PVOID InputBuffer OPTIONAL,
	IN ULONG InputBufferLength,
	OUT PVOID OutputBuffer OPTIONAL,
	IN ULONG OutputBufferLength);

EXTERN_C LONG NtQueueApcThread(
	IN HANDLE ThreadHandle,
	IN PKNORMAL_ROUTINE ApcRoutine,
	IN PVOID ApcArgument1 OPTIONAL,
	IN PVOID ApcArgument2 OPTIONAL,
	IN PVOID ApcArgument3 OPTIONAL);

EXTERN_C LONG NtWaitForMultipleObjects(
	IN ULONG Count,
	IN PHANDLE Handles,
	IN WAIT_TYPE WaitType,
	IN BOOLEAN Alertable,
	IN PLARGE_INTEGER Timeout OPTIONAL);

EXTERN_C LONG NtCreateUserProcess(
	OUT PHANDLE ProcessHandle,
	OUT PHANDLE ThreadHandle,
	IN ACCESS_MASK ProcessDesiredAccess,
	IN ACCESS_MASK ThreadDesiredAccess,
	IN POBJECT_ATTRIBUTES ProcessObjectAttributes OPTIONAL,
	IN POBJECT_ATTRIBUTES ThreadObjectAttributes OPTIONAL,
	IN ULONG ProcessFlags,
	IN ULONG ThreadFlags,
	IN PVOID ProcessParameters OPTIONAL,
	IN OUT PPS_CREATE_INFO CreateInfo,
	IN PPS_ATTRIBUTE_LIST AttributeList OPTIONAL);

SW2_SYSCALL_LIST SW2_SyscallList = {0,1};

DWORD SW2_HashSyscall(PCSTR FunctionName)
{
    DWORD i = 0;
    DWORD Hash = SW2_SEED;

    while (FunctionName[i])
    {
        WORD PartialName = *(WORD*)((ULONG64)FunctionName + i++);
        Hash ^= PartialName + SW2_ROR8(Hash);
    }

    return Hash;
}

BOOL SW2_PopulateSyscallList()
{
    if (SW2_SyscallList.Count) return TRUE;

    PSW2_PEB Peb = (PSW2_PEB)__readgsqword(0x60);
    PSW2_PEB_LDR_DATA Ldr = Peb->Ldr;
    PIMAGE_EXPORT_DIRECTORY ExportDirectory = NULL;
    PVOID DllBase = NULL;

    PSW2_LDR_DATA_TABLE_ENTRY LdrEntry;
    for (LdrEntry = (PSW2_LDR_DATA_TABLE_ENTRY)Ldr->Reserved2[1]; LdrEntry->DllBase != NULL; LdrEntry = (PSW2_LDR_DATA_TABLE_ENTRY)LdrEntry->Reserved1[0])
    {
        DllBase = LdrEntry->DllBase;
        PIMAGE_DOS_HEADER DosHeader = (PIMAGE_DOS_HEADER)DllBase;
        PIMAGE_NT_HEADERS NtHeaders = SW2_RVA2VA(PIMAGE_NT_HEADERS, DllBase, DosHeader->e_lfanew);
        PIMAGE_DATA_DIRECTORY DataDirectory = (PIMAGE_DATA_DIRECTORY)NtHeaders->OptionalHeader.DataDirectory;
        DWORD VirtualAddress = DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
        if (VirtualAddress == 0) continue;

        ExportDirectory = (PIMAGE_EXPORT_DIRECTORY)SW2_RVA2VA(ULONG_PTR, DllBase, VirtualAddress);

        PCHAR DllName = SW2_RVA2VA(PCHAR, DllBase, ExportDirectory->Name);

        if ((*(ULONG*)DllName | 0x20202020) != 'ldtn') continue;
        if ((*(ULONG*)(DllName + 4) | 0x20202020) == 'ld.l') break;
    }

    if (!ExportDirectory) return FALSE;

    DWORD NumberOfNames = ExportDirectory->NumberOfNames;
    PDWORD Functions = SW2_RVA2VA(PDWORD, DllBase, ExportDirectory->AddressOfFunctions);
    PDWORD Names = SW2_RVA2VA(PDWORD, DllBase, ExportDirectory->AddressOfNames);
    PWORD Ordinals = SW2_RVA2VA(PWORD, DllBase, ExportDirectory->AddressOfNameOrdinals);

    DWORD i = 0;
    PSW2_SYSCALL_ENTRY Entries = SW2_SyscallList.Entries;
    do
    {
        PCHAR FunctionName = SW2_RVA2VA(PCHAR, DllBase, Names[NumberOfNames - 1]);

        if (*(USHORT*)FunctionName == 'wZ')
        {
            Entries[i].Hash = SW2_HashSyscall(FunctionName);
            Entries[i].Address = Functions[Ordinals[NumberOfNames - 1]];

            i++;
            if (i == SW2_MAX_ENTRIES) break;
        }
    } while (--NumberOfNames);

    SW2_SyscallList.Count = i;

    for (DWORD i = 0; i < SW2_SyscallList.Count - 1; i++)
    {
        for (DWORD j = 0; j < SW2_SyscallList.Count - i - 1; j++)
        {
            if (Entries[j].Address > Entries[j + 1].Address)
            {
                SW2_SYSCALL_ENTRY TempEntry;

                TempEntry.Hash = Entries[j].Hash;
                TempEntry.Address = Entries[j].Address;

                Entries[j].Hash = Entries[j + 1].Hash;
                Entries[j].Address = Entries[j + 1].Address;

                Entries[j + 1].Hash = TempEntry.Hash;
                Entries[j + 1].Address = TempEntry.Address;
            }
        }
    }

    return TRUE;
}

EXTERN_C DWORD SW2_GetSyscallNumber(DWORD FunctionHash)
{
    if (!SW2_PopulateSyscallList()) return -1;

    for (DWORD i = 0; i < SW2_SyscallList.Count; i++)
    {
        if (FunctionHash == SW2_SyscallList.Entries[i].Hash)
        {
            return i;
        }
    }

    return -1;
}
#define ZwCreateProcess NtCreateProcess
__asm__("NtCreateProcess:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x4fd54c5a, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwCreateThreadEx NtCreateThreadEx
__asm__("NtCreateThreadEx:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x172845f5, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
	ret
");
#define ZwOpenProcess NtOpenProcess
__asm__("NtOpenProcess:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0xedacd400, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwOpenProcessToken NtOpenProcessToken
__asm__("NtOpenProcessToken:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x61f44f68, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwTestAlert NtTestAlert
__asm__("NtTestAlert:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x308b3304, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwOpenThread NtOpenThread
__asm__("NtOpenThread:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0xe99dcaf, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwSuspendProcess NtSuspendProcess
__asm__("NtSuspendProcess:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x45af423c, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwSuspendThread NtSuspendThread
__asm__("NtSuspendThread:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x28902e09, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwResumeProcess NtResumeProcess
__asm__("NtResumeProcess:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x8629477b, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwResumeThread NtResumeThread
__asm__("NtResumeThread:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x250df935, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwGetContextThread NtGetContextThread
__asm__("NtGetContextThread:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x6a4e269d, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwSetContextThread NtSetContextThread
__asm__("NtSetContextThread:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0xf4df39f6, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwClose NtClose
__asm__("NtClose:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0xd4543119, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwReadVirtualMemory NtReadVirtualMemory
__asm__("NtReadVirtualMemory:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0xc5952906, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwWriteVirtualMemory NtWriteVirtualMemory
__asm__("NtWriteVirtualMemory:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x93e6fb, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwAllocateVirtualMemory NtAllocateVirtualMemory
__asm__("NtAllocateVirtualMemory:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x3fa908e7, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwProtectVirtualMemory NtProtectVirtualMemory
__asm__("NtProtectVirtualMemory:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x99b071d, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwFreeVirtualMemory NtFreeVirtualMemory
__asm__("NtFreeVirtualMemory:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x4194751b, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwQuerySystemInformation NtQuerySystemInformation
__asm__("NtQuerySystemInformation:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0xc24bc4df, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwQueryDirectoryFile NtQueryDirectoryFile
__asm__("NtQueryDirectoryFile:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x6432668a, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwQueryInformationFile NtQueryInformationFile
__asm__("NtQueryInformationFile:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x40d64970, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwQueryInformationProcess NtQueryInformationProcess
__asm__("NtQueryInformationProcess:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x812484ac, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwQueryInformationThread NtQueryInformationThread
__asm__("NtQueryInformationThread:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x138f572e, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwCreateSection NtCreateSection
__asm__("NtCreateSection:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x72a91079, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwOpenSection NtOpenSection
__asm__("NtOpenSection:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0xf62fd6fd, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwMapViewOfSection NtMapViewOfSection
__asm__("NtMapViewOfSection:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0xc229c2bb, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwUnmapViewOfSection NtUnmapViewOfSection
__asm__("NtUnmapViewOfSection:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x3aed183d, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwAdjustPrivilegesToken NtAdjustPrivilegesToken
__asm__("NtAdjustPrivilegesToken:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x8650f4db, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwDeviceIoControlFile NtDeviceIoControlFile
__asm__("NtDeviceIoControlFile:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x58c1aa56, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwQueueApcThread NtQueueApcThread
__asm__("NtQueueApcThread:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x1cb79186, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwWaitForMultipleObjects NtWaitForMultipleObjects
__asm__("NtWaitForMultipleObjects:
    mov %rcx, 0x8(%rsp)
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0x542b40a3, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");
#define ZwCreateUserProcess NtCreateUserProcess
__asm__("NtCreateUserProcess:
    mov %rcx, 0x8(%rsp)
    mov %rdx, 0x10(%rsp)
    mov %r8, 0x18(%rsp)
    mov %r9, 0x20(%rsp)
    sub $0x28, %rsp
    mov $0xc3acc032, %ecx
    call SW2_GetSyscallNumber
    add $0x28, %rsp
    mov 0x8(%rsp), %rcx
    mov 0x10(%rsp), %rdx
    mov 0x18(%rsp), %r8
    mov 0x20(%rsp), %r9
    mov %rcx, %r10
    syscall
    ret
");